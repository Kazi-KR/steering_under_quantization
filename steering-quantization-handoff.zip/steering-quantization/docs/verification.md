# Verification record

The repository has been exercised locally on CPU with synthetic fixtures and a tiny randomly initialized Transformers Llama model. The 29 core tests check scenario-group isolation, immutable-data manifests, correct training targets, answer-position balance, answer parsing, hand-computed BBQ scores, intervention location, zero-strength equivalence, hook cleanup, frozen validation selection, resume checks, paired bootstrap units, and the full command workflow. Three additional tests cover handoff archives, partial-result packaging, and credential-free diagnostics: all 32 pass. A standalone CLI smoke run additionally completed extraction, validation, frozen test evaluation, capability evaluation, and report generation. The isolated environment passes `pip check`.

The 128-example pilot extraction sample spans all 30 training scenarios. It creates 576 contrastive pairs with exactly 192 positive and 192 negative occurrences of each answer letter A/B/C. Every positive answer matches the gold label. The detailed source hashes, split manifest, and pair audit are in `data-audit.json`.

Official BBQ gender data was downloaded from commit `bea11bd97d79217245b5871acd247b9d6eb24598`. The grouped split has 3,992 extraction-pool examples (30 scenarios), 912 validation examples (10 scenarios), and 768 test examples (10 scenarios). Each split has equal ambiguous/disambiguated counts. Official target annotations cover all validation/test examples; 16 training-pool examples have missing targets. Raw files and prepared data are ignored by Git and retain source/file hashes locally.

Not yet executed: Qwen2.5-7B inference, real bias-reduction measurements, CUDA LLM.int8()/NF4 execution, a full held-out capability suite, or activation quantization. These are not implied by passing offline tests. The selected GPU environment is still undecided.

The three QA examples bundled in `examples/` are schema examples, not a validation set. Synthetic smoke reports are plumbing diagnostics, not study results. See `local-environment.txt` for the CPU test dependencies and `protocol.md` for experimental boundaries.
