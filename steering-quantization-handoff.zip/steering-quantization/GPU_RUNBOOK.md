# GPU runbook

These commands assume Bash on a Linux machine with an allocated NVIDIA GPU. Run them from the extracted `steering-quantization` folder. Model downloads need internet access; bundled BBQ data does not.

The GPU collaborator's job is to execute the fixed pipeline and return all artifacts. No final bias-reduction result is assumed in advance.

## 1. Create the environment

Use Python 3.10 or newer; Python 3.11 is a reasonable choice on a fresh server. On a cluster, obtain a GPU allocation and load the site's Python/CUDA environment before starting. A login node without an allocated GPU will not work.

```bash
cd /path/to/extracted/steering-quantization
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
```

Install a CUDA-enabled PyTorch build compatible with that machine using the [official installation selector](https://pytorch.org/get-started/locally/) or your site's working PyTorch environment. Then install the project:

```bash
python -m pip install -e '.[dev,quant]'
python -m pip check
mkdir -p logs
set -o pipefail
python scripts/check_gpu.py --output logs/gpu_environment.json
python -m pip freeze > logs/gpu-packages.txt
```

Expected: a visible CUDA GPU, BF16 support, and installed Transformers/Accelerate/bitsandbytes. The intended hardware is one 80 GB GPU. Have ample disk space for the model cache and outputs; reserve at least roughly 50 GB. `CUDA_VISIBLE_DEVICES` can select an allocated GPU; inside the process its visible device is `cuda:0`.

The recorded Mac environment in `docs/local-environment.txt` is for CPU verification. Do not assume it is a working CUDA dependency lock. Save the actual GPU package versions. If the machine cannot support the requested precision, return the diagnostic instead of silently changing experiment precision.

## 2. Run offline checks

```bash
pytest -q 2>&1 | tee logs/tests.log
steerquant smoke --output artifacts/offline-smoke 2>&1 | tee logs/offline-smoke.log
```

Expected: 32 tests pass and the smoke command completes. It uses synthetic questions and a tiny random model; its scores are meaningless for the research task. It does not download Qwen.

If a smoke output directory already exists, keep it for inspection and choose a new output name rather than overwriting it.

## 3. Use the bundled data and inspect the budget

The ZIP already contains `data/raw/bbq/` and `data/prepared/gender/`. Do not re-run `fetch-bbq` or `prepare` into those nonempty folders.

```bash
steerquant plan --config configs/qwen_gender.yaml 2>&1 | tee logs/main-plan.log
```

This validates split hashes. Expected full validation budget: 14 BF16 conditions, 20 INT8 conditions, 20 NF4 conditions, totaling **49,248 generations** over 912 validation examples. No runtime estimate has been measured; the small GPU check comes first.

The initial extraction sample uses 128 examples; the training pool itself has 3,992. Validation and test have 912 and 768 examples, respectively. Split sizes count many variants of a smaller number of scenarios. Do not shuffle or recreate the provided splits.

For a fresh source-only checkout without bundled data, follow the fetch/prepare commands in `README.md`. Use the upstream revision in `docs/data-audit.json` to reproduce this snapshot.

## 4. Run the smaller BF16 GPU check

```bash
steerquant plan --config configs/qwen_gender_gpu_check.yaml 2>&1 | tee logs/gpu-check-plan.log
steerquant lock --config configs/qwen_gender_gpu_check.yaml \
  --output configs/qwen_gender_gpu_check.locked.json
steerquant extract --config configs/qwen_gender_gpu_check.locked.json \
  --precision bf16 2>&1 | tee logs/gpu-check-extract.log
steerquant evaluate --config configs/qwen_gender_gpu_check.locked.json \
  --precision bf16 --split validation 2>&1 | tee logs/gpu-check-validation.log
steerquant summarize --config configs/qwen_gender_gpu_check.locked.json \
  --split validation --output reports/gpu-check 2>&1 | tee logs/gpu-check-report.log
```

The first extraction downloads Qwen's weights. Keep the Hugging Face cache outside the project/artifact folders. Qwen2.5-7B-Instruct is a public checkpoint; use the ordinary Hugging Face credential mechanism only if your environment requires it.

This diagnostic uses 16 extraction examples, one layer, one nonzero strength, and BF16 only. The validation limit preserves whole scenario groups, so its actual question count can exceed 16. `plan` prints the actual count.

Check that extraction finishes, vector norms/scales are finite, runs are marked complete, raw outputs are retained, and invalid/truncation rates are visible in the report. This stage checks execution and output behavior; do not use its scores to redesign the main campaign or inspect the held-out test labels. There is no minimum debiasing score that the run is required to achieve.

## 5. Run the full pilot validation campaign

The small diagnostic and full campaign have separate configurations and artifact roots. Re-extract vectors for the full configuration; diagnostic vectors cannot be substituted.

```bash
steerquant lock --config configs/qwen_gender.yaml \
  --output configs/qwen_gender.locked.json
```

First run BF16:

```bash
steerquant extract --config configs/qwen_gender.locked.json \
  --precision bf16 2>&1 | tee logs/main-bf16-extract.log
steerquant evaluate --config configs/qwen_gender.locked.json \
  --precision bf16 --split validation 2>&1 | tee logs/main-bf16-validation.log
```

Then INT8:

```bash
steerquant extract --config configs/qwen_gender.locked.json \
  --precision int8 2>&1 | tee logs/main-int8-extract.log
steerquant evaluate --config configs/qwen_gender.locked.json \
  --precision int8 --split validation 2>&1 | tee logs/main-int8-validation.log
```

Then NF4:

```bash
steerquant extract --config configs/qwen_gender.locked.json \
  --precision nf4 2>&1 | tee logs/main-nf4-extract.log
steerquant evaluate --config configs/qwen_gender.locked.json \
  --precision nf4 --split validation 2>&1 | tee logs/main-nf4-validation.log
```

Models are loaded/released by each command. One GPU is sufficient for sequential execution. If using multiple GPUs, keep reference extraction first and assign different precisions to different processes/devices. Do not launch the same condition twice concurrently into the same artifact root.

Do not edit source, config, package versions, or prepared data mid-campaign. Those changes affect run identity and comparability. Preserve logs if something fails.

## 6. Freeze settings, then evaluate held-out test

Only after all validation conditions finish:

```bash
steerquant summarize --config configs/qwen_gender.locked.json \
  --split validation --output reports/gender-validation 2>&1 | tee logs/main-validation-report.log
steerquant select --config configs/qwen_gender.locked.json \
  --output artifacts/qwen-gender-seed42/selection.json \
  --accuracy-budget 0.02 --invalid-budget 0.01 --unknown-budget 0.02 \
  2>&1 | tee logs/main-selection.log
steerquant evaluate --config configs/qwen_gender.locked.json \
  --precision all --split test \
  --selection artifacts/qwen-gender-seed42/selection.json \
  2>&1 | tee logs/main-test.log
steerquant summarize --config configs/qwen_gender.locked.json \
  --split test --output reports/gender-test 2>&1 | tee logs/main-test-report.log
```

Selection records any source with no admissible setting. That is a result, not an error to tune away. Reference settings are also applied unchanged to quantized receivers, even when their validation behavior differs. Do not select strengths by test scores.

## 7. Optional capability/neutral-uncertainty evaluation

This first handoff does **not** contain an adequate capability benchmark. The study owner and collaborator should choose a properly sized held-out suite before making a general capability-preservation claim. `examples/neutral_qa.jsonl` shows the schema only.

When a real held-out QA file has been agreed:

```bash
steerquant evaluate --config configs/qwen_gender.locked.json \
  --precision all --split capability \
  --qa-file /path/to/agreed_held_out_qa.jsonl \
  --selection artifacts/qwen-gender-seed42/selection.json \
  2>&1 | tee logs/main-capability.log
steerquant summarize --config configs/qwen_gender.locked.json \
  --split capability --output reports/gender-capability
```

Use the same frozen settings. Record the QA dataset source/license and its exact construction. The QA file must have unique IDs, scenario groups, questions, 2–4 answer choices, and a zero-based gold answer. Keep it unchanged between precisions.

## 8. Return the results

```bash
python scripts/package_results.py --output steering-results.zip
```

Send `steering-results.zip` back to the study owner. It includes the main and GPU-check artifact roots if present, reports, logs, locked configurations, and data provenance. It also creates a hash inventory. It excludes the environment, full model cache, and synthetic offline-smoke outputs. If using nondefault artifact roots, pass `--artifact-root path/to/root` for each one.

Please include a short note stating whether all requested stages finished, the GPU type, and any failures or intentional deviations. A failed/partial run is worth returning: do not send only successful CSV rows or screenshots. Raw predictions and vector metadata are needed to audit the study.

## Interrupted runs and common problems

| Situation | Action |
|---|---|
| No CUDA GPU visible | Check allocation/driver/PyTorch CUDA build. Save `gpu_environment.json`. |
| No BF16 support | Return the diagnostic; do not relabel FP16 as BF16. |
| Missing bitsandbytes or CUDA kernel errors | Verify the machine's supported CUDA/PyTorch/bitsandbytes combination; save the exact error and package list. |
| Model download blocked | Arrange access to the public Hugging Face checkpoint through the site's approved mechanism; preserve the locked revision. |
| Out of GPU memory | Check for other processes and an actual 80 GB allocation. Keep the single-example pipeline and settings intact; return the error if unresolved. |
| Evaluation interrupted | Re-run the identical `evaluate` command with `--resume`. Completed matching conditions are checked/skipped. |
| Vector file already exists | Do not repeat successful extraction. If interrupted before the `.pt` file was finalized, retry; a remaining `.tmp` file is not a completed vector artifact. |
| Config/package/source changed | Use a fresh artifact root and a clearly documented new campaign. Do not mix it with the original results. |
| Selection/report output exists | Keep the existing artifact; choose a new output filename/directory if regenerating. |
| Incomplete validation sweep | Finish/resume every precision's validation conditions before `select`. |
| Invalid outputs or poor debiasing | Preserve them. They are diagnostic/scientific outcomes, not permission to change parsing or remove examples. |

The held-out study is still an exploratory single-model/single-seed pilot. Activation quantization, repeated seeds, broader capability controls, and additional categories/models are subsequent work.
