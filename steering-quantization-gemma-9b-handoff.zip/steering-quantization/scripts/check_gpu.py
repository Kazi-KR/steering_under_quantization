"""Small environment diagnostic. Does not download weights or expose credentials."""

import argparse
import importlib.metadata
import json
import platform
import sys
from pathlib import Path


def diagnostic():
    report = {"python": platform.python_version(), "platform": platform.platform(), "packages": {}, "gpus": [], "problems": []}
    for package in ("steerquant", "torch", "transformers", "accelerate", "bitsandbytes", "numpy"):
        try:
            report["packages"][package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            report["packages"][package] = None
            report["problems"].append(f"Missing package: {package}")
    try:
        import torch
        report["cuda_available"] = torch.cuda.is_available()
        report["pytorch_cuda_runtime"] = torch.version.cuda
        if not torch.cuda.is_available():
            report["problems"].append("No CUDA GPU available to this Python process")
        else:
            for index in range(torch.cuda.device_count()):
                with torch.cuda.device(index):
                    free, total = torch.cuda.mem_get_info(index)
                    report["gpus"].append({"index": index, "name": torch.cuda.get_device_name(index),
                                           "total_gib": total / 1024**3, "free_gib": free / 1024**3,
                                           "bf16_supported": bool(torch.cuda.is_bf16_supported())})
            if not report["gpus"][0]["bf16_supported"]:
                report["problems"].append("Visible cuda:0 does not support the requested BF16 reference")
    except Exception as exc:
        report["problems"].append(f"PyTorch diagnostic failed: {type(exc).__name__}: {exc}")
    report["ready_for_gpu_check"] = not report["problems"]
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="logs/gpu_environment.json")
    args = parser.parse_args()
    report = diagnostic()
    path = Path(args.output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0 if report["ready_for_gpu_check"] else 1


if __name__ == "__main__":
    sys.exit(main())
