"""Reproduce the first run's exact scenario partition from official BBQ inputs."""

import argparse
from pathlib import Path

from steerquant.data import load_metadata, normalize
from steerquant.io import ensure_new_directory, file_hash, read_json, read_jsonl, write_json, write_jsonl


def rebuild(raw, metadata, partition, output):
    partition = read_json(partition)
    manifest = partition["manifest"]
    if file_hash(raw) != manifest["raw_sha256"] or file_hash(metadata) != manifest["metadata_sha256"]:
        raise ValueError("Official BBQ inputs differ from the audited first-run snapshot")
    groups = {name: set(values) for name, values in partition["groups"].items()}
    if groups["train"] & groups["validation"] or groups["train"] & groups["test"] or groups["validation"] & groups["test"]:
        raise ValueError("Scenario groups overlap")
    annotations = load_metadata(metadata)
    rows = [normalize(r, annotations) for r in read_jsonl(raw)]
    if {r["group"] for r in rows} != set.union(*groups.values()):
        raise ValueError("Scenario partition does not cover exactly the official dataset")
    dest = ensure_new_directory(output)
    for name, subset in groups.items():
        path = dest / f"{name}.jsonl"
        write_jsonl(path, [r for r in rows if r["group"] in subset])
        if file_hash(path) != manifest["splits"][name]["sha256"]:
            raise ValueError(f"Reconstructed {name} differs from first-run hash")
    write_json(dest / "manifest.json", manifest)
    return dest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw", default="data/raw/bbq/Gender_identity.jsonl")
    parser.add_argument("--metadata", default="data/raw/bbq/additional_metadata.csv")
    parser.add_argument("--partition", default="configs/gender_run1_partition.json")
    parser.add_argument("--output", default="data/prepared/gender-run1")
    args = parser.parse_args()
    print(rebuild(args.raw, args.metadata, args.partition, args.output))


if __name__ == "__main__":
    main()
