# Start here — GPU handoff

**Current target: Gemma-2-9B-IT (`google/gemma-2-9b-it`). Follow [GEMMA_RUNBOOK.md](GEMMA_RUNBOOK.md).** The quantization hypothesis is unchanged. Qwen instructions below describe the first campaign and are retained for its reproduction. The new bundle includes the exact first-run scenario partition under `data/prepared/gender-run1/` and separate Gemma output roots.

This package contains the experimental code, prepared data, and instructions for a study of **bias-reduction activation steering under model quantization**.

**The immediate request:** run the Gemma gender-bias campaign on a Linux NVIDIA GPU, establishing a useful BF16 steering effect before quantization. An 80 GB GPU is the intended environment. The Qwen pilot is complete; no real Gemma-9B results have been collected yet.

## Read in this order

1. [Project idea](PROJECT_IDEA.md): what we want to learn, the experiment, and how to interpret it.
2. [Gemma GPU runbook](GEMMA_RUNBOOK.md): current copyable commands, from installation to returning results.
3. [File guide](FILE_GUIDE.md): what every code/configuration/documentation file does.
4. [Detailed protocol](docs/protocol.md): exact extraction, intervention, scoring, and selection rules.

## What is included

- Independently implemented Python research package, CLI, and 38 offline tests, including Gemma2 architecture, turn stopping, and no-intervention selection.
- Current Gemma main config and a smaller BF16-only GPU-check config; original Qwen configs retained.
- Official BBQ gender, age, and race raw data; scoring metadata; provenance and dataset license.
- Ready-to-use, audited gender files: `gender-run1` matches the first run exactly; `gender` retains the original partition.
- GPU diagnostic and results-packaging scripts.
- A SHA-256 inventory of the bundle, in `BUNDLE_INFO.json` in the ZIP.

Model weights, Python environments, credentials, prior synthetic outputs, and Git history are not included. The initial model download needs internet access. The bundled raw data retains its own CC BY 4.0 license; the independently written pipeline has the MIT license in the repository root.

## What has already been checked

- 38 tests pass in the documented local CPU environment.
- A random tiny-transformer smoke test completes extraction, validation, selection, held-out testing, capability evaluation, and reporting without downloading a model.
- The current matched gender split has 3,192 training-pool examples, 1,240 validation examples, and 1,240 test examples, with no shared scenario groups and hashes identical to the returned first run.
- The original split and pair audit are retained in `docs/data-audit.json`; the current exact partition/manifest is in `configs/gender_run1_partition.json`.

The full Gemma-9B model and its bitsandbytes CUDA paths still need execution. Tiny-model tests and CPU smoke scores are not study results.

## First actions

Unzip the archive and open a terminal in the extracted `steering-quantization` folder. Follow [GEMMA_RUNBOOK.md](GEMMA_RUNBOOK.md): obtain model access, install, test, verify the bundled data, and run the small GPU check. Keep its output separate from the main experiment.

After the GPU check, establish a useful BF16 validation effect before continuing to quantization. Then finish validation, freeze the selected settings, run the held-out test, and return the result ZIP. If the run fails, return the logs and partial artifacts instead of changing the scientific settings to make the errors disappear.

The original `README.md` is the general developer guide. For this bundled handoff, use the runbook as the main execution guide: data preparation is already complete, so downloading/preparing the same data again is unnecessary.
