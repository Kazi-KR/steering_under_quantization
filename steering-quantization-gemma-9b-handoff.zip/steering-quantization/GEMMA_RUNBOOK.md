# Current campaign: Gemma-2-9B-IT

**Model:** `google/gemma-2-9b-it`. **Research question:** does weight quantization change the effectiveness of bias-reduction activation steering? This is the original quantization hypothesis. Qwen's first run is retained as a pilot; Gemma is now the primary target.

Use this guide for the new handoff. `GPU_RUNBOOK.md` and the Qwen configs document the previous campaign.

## Access and environment

Use the same Linux NVIDIA GPU environment as the first run, or an allocated 80 GB GPU. Before downloading Gemma, the GPU operator must obtain access to [the model](https://huggingface.co/google/gemma-2-9b-it), accept its terms in their own account, and authenticate with a read-capable Hugging Face token. No token is bundled or recorded in results.

From the extracted project root:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
# Install the site's appropriate CUDA-enabled PyTorch build first if needed.
python -m pip install -e '.[dev,quant]'
hf auth login
mkdir -p logs
set -o pipefail
python scripts/check_gpu.py --output logs/gemma-gpu-environment.json
python -m pip freeze > logs/gemma-packages.txt
pytest -q 2>&1 | tee logs/gemma-tests.log
```

A tiny randomly initialized Gemma2 is exercised by the offline tests, including actual intervention and end-of-turn stopping. Passing these tests does not establish bias reduction or validate the full 9B CUDA kernels.

## Data

`data/prepared/gender-run1/` contains the exact audited first-run scenario partition: 3,192 training-pool examples, 1,240 validation examples, and 1,240 test examples. There are 27/11/12 independent scenario groups, respectively. The model's extraction sample uses 128 training examples. No Qwen steering vector or prediction is used for Gemma extraction.

All three split hashes match the returned first-run manifest. The ZIP includes this data, so no preparation command is needed. A source-only checkout can recreate it after obtaining the official raw data:

```bash
python scripts/rebuild_run1_splits.py
```

The fixed partition is in `configs/gender_run1_partition.json`; this reproduces the returned scenario assignment without depending on unarchived data-preparation changes. Keep the previous `data/prepared/gender/` separate. This campaign is exploratory: the first-run test has already been inspected, so it is not a fresh confirmatory evaluation set.

## 1. Small execution check

```bash
steerquant lock --config configs/gemma_gender_gpu_check.yaml \
  --output configs/gemma_gender_gpu_check.locked.json
steerquant plan --config configs/gemma_gender_gpu_check.locked.json
steerquant extract --config configs/gemma_gender_gpu_check.locked.json \
  --precision bf16 2>&1 | tee logs/gemma-gpu-check-extract.log
steerquant evaluate --config configs/gemma_gender_gpu_check.locked.json \
  --precision bf16 --split validation 2>&1 | tee logs/gemma-gpu-check-validation.log
steerquant summarize --config configs/gemma_gender_gpu_check.locked.json \
  --split validation --output reports/gemma-gpu-check
```

This uses a small extraction sample, one layer, and one nonzero dose, in `artifacts/gemma-gpu-check/`. It checks loading, tokenization, hooks, output validity, and stop tokens. It does not decide the study's steering efficacy.

Gemma uses its own decoder adapter and checkpoint-defined stop IDs, including end-of-turn when configured. Its residual intervention convention is unchanged: zero-based block output, last prompt position followed by each cached generation position.

## 2. Establish the BF16 reference effect

```bash
steerquant lock --config configs/gemma_gender.yaml \
  --output configs/gemma_gender.locked.json
steerquant plan --config configs/gemma_gender.locked.json \
  2>&1 | tee logs/gemma-main-plan.log
steerquant extract --config configs/gemma_gender.locked.json \
  --precision bf16 2>&1 | tee logs/gemma-bf16-extract.log
steerquant evaluate --config configs/gemma_gender.locked.json \
  --precision bf16 --split validation 2>&1 | tee logs/gemma-bf16-validation.log
steerquant summarize --config configs/gemma_gender.locked.json \
  --split validation --output reports/gemma-bf16-validation
```

The main configuration evaluates layers 12, 20, and 28 separately (approximately 30%, 50%, and 70% of Gemma-2-9B's 42 blocks). These are validation search settings, not claims about the best layer. The original relative-strength grid is retained, along with unsteered, random-vector, and fairness-prompt controls.

**Checkpoint before quantization:** inspect the BF16 validation report. A useful effect means reducing unsupported stereotypical attribution while retaining evidence-based answering and output validity, beyond comparable random perturbations. A vector being extracted successfully or changing answers is not enough. If the learned direction has no useful BF16 effect, return the validation artifacts before spending time on all quantized conditions. Do not inspect test results to choose a layer or dose.

This is an execution/scientific checkpoint for the existing study, not a new hypothesis or a claim that Gemma must steer successfully. The full BF16 grid has 38 conditions and 47,120 validation generations. Across all three precisions the grid has 150 conditions and 186,000 validation generations. No wall-clock estimate has been measured for Gemma.

## 3. Quantized receivers

When the BF16 reference is useful, keep the locked config and continue:

```bash
steerquant extract --config configs/gemma_gender.locked.json \
  --precision int8 2>&1 | tee logs/gemma-int8-extract.log
steerquant evaluate --config configs/gemma_gender.locked.json \
  --precision int8 --split validation 2>&1 | tee logs/gemma-int8-validation.log
steerquant extract --config configs/gemma_gender.locked.json \
  --precision nf4 2>&1 | tee logs/gemma-nf4-extract.log
steerquant evaluate --config configs/gemma_gender.locked.json \
  --precision nf4 --split validation 2>&1 | tee logs/gemma-nf4-validation.log
steerquant summarize --config configs/gemma_gender.locked.json \
  --split validation --output reports/gemma-validation
```

The same BF16 vectors transfer into each receiver, and native vectors are extracted again at each precision. All doses use the original BF16 activation scale. LLM.int8() and NF4 are deployment schemes with different algorithms; LLM.int8() also uses internally quantized matmul inputs, so this is not an isolated bit-width-only causal experiment.

## 4. Freeze selection and evaluate

The selector now allows zero intervention separately for each vector source and prefers it when validation outcomes tie. `baseline_preferred` and `no_nonzero_reference_selected` are explicit diagnostics. They must not be presented as successful nonzero steering. Unchanged-reference transfer settings are added only when a nonzero reference setting is selected.

```bash
steerquant select --config configs/gemma_gender.locked.json \
  --output artifacts/gemma-gender-seed42/selection.json \
  --accuracy-budget 0.02 --invalid-budget 0.01 --unknown-budget 0.02
steerquant evaluate --config configs/gemma_gender.locked.json \
  --precision all --split test \
  --selection artifacts/gemma-gender-seed42/selection.json \
  2>&1 | tee logs/gemma-test.log
steerquant summarize --config configs/gemma_gender.locked.json \
  --split test --output reports/gemma-test
```

For capability controls, use the exact agreed first-run filtered MMLU/adapted SQuAD QA file from the GPU machine, not the three formatting examples. Its first-run SHA-256 is `8c194ca20cbffc5b74e851b4788fccfdf3c99cd7d3557ee0c4978cb67570c867`. That QA file was not included in the returned results, so the operator should retain it on their machine and include it with the next result archive. Do not treat the adapted multiple-choice SQuAD scores as standard SQuAD benchmark scores.

```bash
steerquant evaluate --config configs/gemma_gender.locked.json \
  --precision all --split capability --qa-file data/capability/qa.jsonl \
  --selection artifacts/gemma-gender-seed42/selection.json \
  2>&1 | tee logs/gemma-capability.log
steerquant summarize --config configs/gemma_gender.locked.json \
  --split capability --output reports/gemma-capability
python scripts/package_results.py --output gemma-steering-results.zip
```

The results packager includes the Gemma artifact roots and an executed-source snapshot. Return a partial archive even if BF16 is unsuccessful or a CUDA step fails. Model weights, caches, environments, and credentials remain excluded. Resume matching evaluation commands with `--resume`; do not mix modified configs/code with an existing campaign.
